import random

def diet_suggestion():
    print("\n╔═══════════════════════════════════════════════════╗")
    print("║     🥗 SISTEM SARAN MAKANAN DIET & NUTRISI 🥗     ║")
    print("╚═══════════════════════════════════════════════════╝\n")

    # Input Berat Badan
    try:
        current_weight = float(input("📊 Masukkan berat badan Anda saat ini (kg): "))
        target_weight = float(input("🎯 Masukkan berat badan target (kg): "))
        height = float(input("📏 Masukkan tinggi badan Anda (cm): "))

        if current_weight <= 0 or target_weight <= 0 or height <= 0:
            print("❌ Berat dan tinggi badan harus lebih dari 0!")
            return

        weight_difference = target_weight - current_weight

        # Hitung BMI
        height_m = height / 100
        bmi = current_weight / (height_m ** 2)

    except ValueError:
        print("❌ Input tidak valid! Mohon masukkan angka yang benar.")
        return

    # Input Alergi
    print("\n🚫 Alergi makanan Anda? (Pisahkan dengan koma, atau ketik 'tidak ada'):")
    print("   Contoh: susu, kacang, telur, gluten")
    allergies_input = input("➜ ").strip().lower()
    allergies = [a.strip() for a in allergies_input.split(',') if a.strip() and a.strip() != 'tidak ada']

    # Input Waktu Makan
    print("\n⏰ Untuk waktu makan apa saran ini diperlukan?")
    print("   1. Sarapan")
    print("   2. Makan Siang")
    print("   3. Makan Malam")
    print("   4. Snack/Camilan")
    meal_choice = input("➜ Pilih (1/2/3/4): ")

    meal_times = {
        '1': "Sarapan",
        '2': "Makan Siang",
        '3': "Makan Malam",
        '4': "Snack/Camilan"
    }
    meal_time = meal_times.get(meal_choice, "Makanan Umum")

    # Input Preferensi Diet
    print("\n🌱 Apakah Anda memiliki preferensi diet khusus?")
    print("   1. Tidak ada")
    print("   2. Vegetarian")
    print("   3. Non-vegetarian")
    diet_pref = input("➜ Pilih (1/2/3): ")

    # Tentukan Kategori BMI
    bmi_category = ""
    if bmi < 18.5:
        bmi_category = "Kekurangan Berat Badan"
    elif 18.5 <= bmi < 25:
        bmi_category = "Normal"
    elif 25 <= bmi < 30:
        bmi_category = "Kelebihan Berat Badan"
    else:
        bmi_category = "Obesitas"

    # Tentukan Tujuan
    goal = ""
    if weight_difference > 0:
        goal = "Penambahan Berat Badan"
    elif weight_difference < 0:
        goal = "Penurunan Berat Badan"
    else:
        goal = "Mempertahankan Berat Badan"

    # Tampilkan Ringkasan
    print("\n" + "="*60)
    print("📋 RINGKASAN PROFIL NUTRISI")
    print("="*60)
    print(f"Berat Badan Saat Ini  : {current_weight} kg")
    print(f"Berat Badan Target    : {target_weight} kg")
    print(f"Tinggi Badan          : {height} cm")
    print(f"BMI Anda              : {bmi:.1f} ({bmi_category})")

    goal_info = ""
    if weight_difference > 0:
        goal_info = f"{goal} (+{weight_difference:.1f} kg)"
    elif weight_difference < 0:
        goal_info = f"{goal} ({weight_difference:.1f} kg)"
    else:
        goal_info = goal
    print(f"Tujuan                : {goal_info}")

    if allergies:
        print(f"Alergi                : {', '.join([a.capitalize() for a in allergies])}")
    else:
        print(f"Alergi                : Tidak Ada")

    print(f"Waktu Makan           : {meal_time}")
    print("="*60 + "\n")

    # Database Resep yang Diperluas
    recipes = get_recipes(goal, meal_time, diet_pref)

    if recipes:
        # Pilih resep acak
        recipe = random.choice(recipes)

        # Cek Alergi
        contains_allergen = False
        allergen_list = []

        if allergies:
            for ingredient in recipe['Bahan']:
                for allergen in allergies:
                    if allergen in ingredient.lower():
                        contains_allergen = True
                        allergen_list.append(allergen.capitalize())

        # Tampilkan Resep
        print("┏" + "━"*58 + "┓")
        print(f"┃ 🍽️  {recipe['Nama']:^53} ┃")
        print("┗" + "━"*58 + "┛\n")

        if contains_allergen:
            print("⚠️  " + "="*56)
            print(f"⚠️  PERINGATAN ALERGI: Resep mengandung {', '.join(set(allergen_list))}")
            print("⚠️  Harap ganti atau hilangkan bahan tersebut!")
            print("⚠️  " + "="*56 + "\n")
        else:
            print("✅ Resep ini aman dari alergi yang Anda sebutkan.\n")

        # Informasi Nutrisi
        if 'Nutrisi' in recipe:
            print("📊 INFORMASI NUTRISI (per porsi):")
            print("   " + "─"*54)
            for key, value in recipe['Nutrisi'].items():
                print(f"   {key:20} : {value}")
            print()

        # Bahan-bahan
        print("📝 BAHAN-BAHAN:")
        print("   " + "─"*54)
        for i, bahan in enumerate(recipe['Bahan'], 1):
            print(f"   {i}. {bahan}")
        print()

        # Cara Pembuatan
        print("🧑‍🍳 CARA PEMBUATAN:")
        print("   " + "─"*54)
        for i, cara in enumerate(recipe['Cara'], 1):
            print(f"   {i}. {cara}")
        print()

        # Tips Tambahan
        if 'Tips' in recipe:
            print("💡 TIPS:")
            print("   " + "─"*54)
            for tip in recipe['Tips']:
                print(f"   • {tip}")
            print()

        # Saran Tambahan
        print("💪 SARAN TAMBAHAN:")
        print("   " + "─"*54)
        if goal == "Penurunan Berat Badan":
            print("   • Minum air putih minimal 8 gelas per hari")
            print("   • Olahraga kardio 30-45 menit, 3-5x seminggu")
            print("   • Hindari makanan tinggi gula dan gorengan")
            print("   • Tidur cukup 7-8 jam per hari")
        elif goal == "Penambahan Berat Badan":
            print("   • Makan lebih sering (5-6 kali sehari dengan porsi kecil)")
            print("   • Fokus pada latihan beban untuk membangun otot")
            print("   • Konsumsi smoothie atau shake tinggi kalori")
            print("   • Istirahat cukup untuk pemulihan otot")
        else:
            print("   • Pertahankan pola makan seimbang")
            print("   • Olahraga rutin minimal 30 menit per hari")
            print("   • Monitor berat badan secara berkala")
            print("   • Jaga asupan sayur dan buah harian")
        print()

    else:
        print("❌ Maaf, tidak ada resep yang tersedia untuk kombinasi ini.\n")

def get_recipes(goal, meal_time, diet_pref):
    """Database resep yang komprehensif"""
    recipes = []

    # ===== RESEP PENURUNAN BERAT BADAN =====
    if goal == "Penurunan Berat Badan":
        if meal_time == "Sarapan":
            recipes.extend([
                {
                    'Nama': 'Oatmeal dengan Beri dan Biji Chia',
                    'Bahan': [
                        '3 sdm Oat',
                        '1/2 cangkir Susu Almond',
                        '1/4 cangkir Beri Campuran (Blueberry, Strawberry)',
                        '1 sdm Biji Chia',
                        '1 sdt Madu Murni',
                        'Sejumput Kayu Manis'
                    ],
                    'Cara': [
                        'Rendam oat dengan susu almond selama 5 menit',
                        'Masak dengan api kecil sambil diaduk hingga kental (5-7 menit)',
                        'Tuang ke mangkuk, biarkan dingin sebentar',
                        'Tambahkan beri segar di atasnya',
                        'Taburkan biji chia dan kayu manis',
                        'Teteskan madu dan sajikan'
                    ],
                    'Nutrisi': {
                        'Kalori': '~280 kal',
                        'Protein': '8g',
                        'Karbohidrat': '45g',
                        'Lemak': '7g',
                        'Serat': '9g'
                    },
                    'Tips': [
                        'Gunakan oat organik untuk hasil terbaik',
                        'Bisa ditambah protein powder untuk protein ekstra'
                    ]
                },
                {
                    'Nama': 'Telur Orak-Arik dengan Sayuran',
                    'Bahan': [
                        '2 butir Telur',
                        '1/4 Paprika Merah (potong dadu)',
                        '1/4 Bawang Bombay (cincang)',
                        '1 genggam Bayam Segar',
                        '1 sdt Minyak Zaitun',
                        'Garam dan Lada secukupnya'
                    ],
                    'Cara': [
                        'Kocok telur dengan garam dan lada',
                        'Panaskan minyak zaitun di wajan',
                        'Tumis bawang bombay hingga harum',
                        'Masukkan paprika, tumis 2 menit',
                        'Tambahkan bayam, masak hingga layu',
                        'Tuang telur, aduk perlahan hingga matang'
                    ],
                    'Nutrisi': {
                        'Kalori': '~220 kal',
                        'Protein': '14g',
                        'Karbohidrat': '8g',
                        'Lemak': '15g',
                        'Serat': '2g'
                    },
                    'Tips': [
                        'Jangan masak telur terlalu lama agar tidak kering',
                        'Bisa tambahkan tomat cherry untuk rasa segar'
                    ]
                },
                {
                    'Nama': 'Smoothie Bowl Hijau Rendah Kalori',
                    'Bahan': [
                        '1 Pisang Beku',
                        '1 cangkir Bayam Segar',
                        '1/2 cangkir Greek Yogurt Rendah Lemak',
                        '1/4 cangkir Susu Almond',
                        '1 sdt Madu',
                        'Topping: Beri, Biji Chia, Granola (sedikit)'
                    ],
                    'Cara': [
                        'Blend pisang beku, bayam, yogurt, dan susu hingga halus',
                        'Tuang ke mangkuk',
                        'Tata topping beri, biji chia, dan sedikit granola',
                        'Teteskan madu',
                        'Sajikan segera'
                    ],
                    'Nutrisi': {
                        'Kalori': '~260 kal',
                        'Protein': '12g',
                        'Karbohidrat': '42g',
                        'Lemak': '5g',
                        'Serat': '6g'
                    },
                    'Tips': ['Bekukan pisang semalaman untuk tekstur creamy']
                }
            ])

        elif meal_time in ["Makan Siang", "Makan Malam"]:
            base_recipes = [
                {
                    'Nama': 'Salad Ayam Panggang dengan Quinoa',
                    'Bahan': [
                        '100g Dada Ayam (marinasi dengan lemon dan herbs)',
                        '1/2 cangkir Quinoa Matang',
                        '2 cangkir Campuran Sayuran Hijau (Selada, Rocket, Bayam)',
                        '1/4 cangkir Tomat Ceri (belah dua)',
                        '1/4 Timun (iris)',
                        '2 sdm Dressing Lemon Vinaigrette',
                        '1 sdm Biji Wijen Panggang'
                    ],
                    'Cara': [
                        'Marinasi ayam dengan perasan lemon, oregano, garam, lada (30 menit)',
                        'Panggang ayam dalam oven 180°C selama 20 menit',
                        'Masak quinoa sesuai instruksi kemasan',
                        'Tata sayuran hijau di piring',
                        'Tambahkan quinoa yang sudah dingin',
                        'Letakkan ayam panggang yang sudah diiris',
                        'Tambahkan tomat dan timun',
                        'Siram dengan dressing dan taburi biji wijen'
                    ],
                    'Nutrisi': {
                        'Kalori': '~380 kal',
                        'Protein': '32g',
                        'Karbohidrat': '35g',
                        'Lemak': '12g',
                        'Serat': '6g'
                    },
                    'Tips': [
                        'Quinoa bisa diganti dengan brown rice',
                        'Buat dressing sendiri: 2 sdm lemon + 1 sdm olive oil + mustard'
                    ]
                },
                {
                    'Nama': 'Sup Sayuran dengan Dada Ayam',
                    'Bahan': [
                        '100g Dada Ayam (potong dadu)',
                        '2 cangkir Kaldu Ayam Rendah Natrium',
                        '1/2 Wortel (potong dadu)',
                        '1/2 Brokoli (potong kecil)',
                        '1/4 Kembang Kol',
                        '2 batang Seledri (iris)',
                        '2 siung Bawang Putih (cincang)',
                        '1 sdt Minyak Zaitun',
                        'Garam, Lada, Bubuk Kunyit'
                    ],
                    'Cara': [
                        'Panaskan minyak, tumis bawang putih hingga harum',
                        'Masukkan ayam, masak hingga berubah warna',
                        'Tuang kaldu ayam, didihkan',
                        'Masukkan wortel dan seledri, masak 5 menit',
                        'Tambahkan brokoli dan kembang kol',
                        'Bumbui dengan garam, lada, dan kunyit',
                        'Masak hingga sayuran empuk tapi tidak lembek (10 menit)',
                        'Sajikan hangat'
                    ],
                    'Nutrisi': {
                        'Kalori': '~250 kal',
                        'Protein': '28g',
                        'Karbohidrat': '18g',
                        'Lemak': '7g',
                        'Serat': '5g'
                    },
                    'Tips': [
                        'Tambahkan jahe untuk rasa hangat',
                        'Bisa tambahkan soun untuk membuat lebih mengenyangkan'
                    ]
                },
                {
                    'Nama': 'Ikan Panggang dengan Asparagus',
                    'Bahan': [
                        '120g Ikan Dori/Kakap',
                        '10 batang Asparagus',
                        '1/2 Lemon (iris)',
                        '2 siung Bawang Putih (cincang)',
                        '1 sdm Minyak Zaitun',
                        'Garam, Lada, Rosemary'
                    ],
                    'Cara': [
                        'Marinasi ikan dengan bawang putih, garam, lada, lemon (15 menit)',
                        'Panggang ikan dalam oven 180°C (15 menit)',
                        'Panggang asparagus dengan olive oil, garam, lada (10 menit)',
                        'Sajikan ikan dengan asparagus dan irisan lemon'
                    ],
                    'Nutrisi': {
                        'Kalori': '~280 kal',
                        'Protein': '30g',
                        'Karbohidrat': '10g',
                        'Lemak': '14g',
                        'Serat': '4g'
                    },
                    'Tips': ['Ikan kaya Omega-3 baik untuk jantung']
                },
                {
                    'Nama': 'Zucchini Noodles dengan Saus Tomat',
                    'Bahan': [
                        '2 Zucchini Besar (spiral/potong seperti mie)',
                        '1 cangkir Saus Tomat Buatan Sendiri',
                        '100g Dada Ayam Cincang/Daging Sapi Giling Rendah Lemak',
                        '2 siung Bawang Putih (cincang)',
                        'Basil Segar',
                        '1 sdm Minyak Zaitun',
                        'Garam dan Lada'
                    ],
                    'Cara': [
                        'Potong zucchini menjadi bentuk mie (gunakan spiralizer atau pisau)',
                        'Panaskan minyak, tumis bawang putih',
                        'Masak ayam/daging hingga matang',
                        'Tambahkan saus tomat, masak 5 menit',
                        'Tumis zucchini noodles sebentar (2-3 menit)',
                        'Campurkan dengan saus',
                        'Taburi basil segar'
                    ],
                    'Nutrisi': {
                        'Kalori': '~290 kal',
                        'Protein': '26g',
                        'Karbohidrat': '22g',
                        'Lemak': '12g',
                        'Serat': '5g'
                    },
                    'Tips': ['Alternatif pasta rendah karbohidrat yang sehat']
                }
            ]

            # Tambahkan opsi vegetarian jika dipilih
            if diet_pref == '2':
                base_recipes.extend([
                    {
                        'Nama': 'Salad Lentil Mediterania',
                        'Bahan': [
                            '1 cangkir Lentil Hijau Matang',
                            '2 cangkir Sayuran Hijau',
                            '1/2 Mentimun (potong dadu)',
                            '1/4 cangkir Tomat Ceri',
                            '2 sdm Olive Oil',
                            '1 sdm Perasan Lemon',
                            '1/4 Bawang Merah (iris tipis)',
                            'Peterseli segar',
                            'Garam dan Lada'
                        ],
                        'Cara': [
                            'Masak lentil hingga empuk, tiriskan',
                            'Campur lentil dengan sayuran hijau',
                            'Tambahkan mentimun, tomat, dan bawang merah',
                            'Buat dressing dari olive oil, lemon, garam, lada',
                            'Tuang dressing, aduk rata',
                            'Taburi peterseli cincang',
                            'Sajikan dingin atau suhu ruang'
                        ],
                        'Nutrisi': {
                            'Kalori': '~320 kal',
                            'Protein': '18g',
                            'Karbohidrat': '40g',
                            'Lemak': '10g',
                            'Serat': '15g'
                        },
                        'Tips': [
                            'Lentil kaya protein nabati',
                            'Bisa tambahkan feta cheese untuk rasa ekstra'
                        ]
                    },
                    {
                        'Nama': 'Tumis Tahu dengan Sayuran',
                        'Bahan': [
                            '200g Tahu Putih (potong dadu)',
                            '1 Brokoli (potong kecil)',
                            '1/2 Wortel (iris)',
                            '1/2 Paprika Merah',
                            '2 siung Bawang Putih',
                            '1 sdm Kecap Asin Rendah Sodium',
                            '1 sdt Minyak Wijen',
                            'Jahe Parut'
                        ],
                        'Cara': [
                            'Goreng tahu hingga keemasan, sisihkan',
                            'Tumis bawang putih dan jahe',
                            'Masukkan sayuran, tumis hingga setengah matang',
                            'Tambahkan tahu, kecap asin',
                            'Aduk hingga bumbu merata',
                            'Teteskan minyak wijen'
                        ],
                        'Nutrisi': {
                            'Kalori': '~270 kal',
                            'Protein': '20g',
                            'Karbohidrat': '18g',
                            'Lemak': '14g',
                            'Serat': '6g'
                        },
                        'Tips': ['Tahu sumber protein nabati berkualitas tinggi']
                    }
                ])

            recipes.extend(base_recipes)

        elif meal_time == "Snack/Camilan":
            recipes.extend([
                {
                    'Nama': 'Greek Yogurt dengan Buah',
                    'Bahan': [
                        '3/4 cangkir Greek Yogurt Plain',
                        '1/2 cangkir Buah Beri Campuran',
                        '1 sdm Almond Slice',
                        '1 sdt Madu',
                        'Sejumput Kayu Manis'
                    ],
                    'Cara': [
                        'Tuang yogurt ke dalam mangkuk',
                        'Tambahkan buah beri segar',
                        'Taburkan almond slice',
                        'Teteskan madu',
                        'Taburi kayu manis dan sajikan'
                    ],
                    'Nutrisi': {
                        'Kalori': '~180 kal',
                        'Protein': '15g',
                        'Karbohidrat': '20g',
                        'Lemak': '5g',
                        'Serat': '3g'
                    },
                    'Tips': ['Pilih yogurt tanpa gula tambahan']
                },
                {
                    'Nama': 'Edamame Rebus dengan Garam Laut',
                    'Bahan': [
                        '1 cangkir Edamame Beku',
                        '1 sdt Garam Laut',
                        'Air untuk merebus'
                    ],
                    'Cara': [
                        'Didihkan air dalam panci',
                        'Masukkan edamame, rebus 5 menit',
                        'Tiriskan dan biarkan uap menghilang',
                        'Taburi dengan garam laut',
                        'Sajikan hangat'
                    ],
                    'Nutrisi': {
                        'Kalori': '~120 kal',
                        'Protein': '11g',
                        'Karbohidrat': '10g',
                        'Lemak': '5g',
                        'Serat': '5g'
                    },
                    'Tips': ['Sumber protein nabati yang sangat baik']
                },
                {
                    'Nama': 'Apple Slices dengan Almond Butter',
                    'Bahan': [
                        '1 Apel Hijau (iris tipis)',
                        '1.5 sdm Almond Butter',
                        'Sejumput Kayu Manis'
                    ],
                    'Cara': [
                        'Iris apel menjadi 8-10 bagian',
                        'Sajikan dengan almond butter untuk dipping',
                        'Taburi dengan kayu manis'
                    ],
                    'Nutrisi': {
                        'Kalori': '~190 kal',
                        'Protein': '5g',
                        'Karbohidrat': '25g',
                        'Lemak': '9g',
                        'Serat': '6g'
                    },
                    'Tips': ['Kombinasi serat dan lemak sehat yang mengenyangkan']
                },
                {
                    'Nama': 'Telur Rebus dan Cherry Tomatoes',
                    'Bahan': [
                        '2 butir Telur Rebus',
                        '10 Cherry Tomatoes',
                        'Sejumput Garam dan Lada',
                        'Basil Segar (opsional)'
                    ],
                    'Cara': [
                        'Rebus telur hingga matang (10 menit)',
                        'Dinginkan dalam air es',
                        'Kupas dan belah dua',
                        'Sajikan dengan cherry tomatoes',
                        'Beri sedikit garam, lada, dan basil'
                    ],
                    'Nutrisi': {
                        'Kalori': '~160 kal',
                        'Protein': '13g',
                        'Karbohidrat': '6g',
                        'Lemak': '10g',
                        'Serat': '1g'
                    },
                    'Tips': ['Camilan tinggi protein yang mudah dibawa']
                }
            ])

    # ===== RESEP PENAMBAHAN BERAT BADAN =====
    elif goal == "Penambahan Berat Badan":
        if meal_time == "Sarapan":
            recipes.extend([
                {
                    'Nama': 'Smoothie Bowl Tinggi Kalori',
                    'Bahan': [
                        '2 Pisang Matang',
                        '3 sdm Selai Kacang',
                        '1 cangkir Susu Full Cream',
                        '2 sdm Bubuk Protein',
                        '3 sdm Oat',
                        '1 sdm Biji Chia',
                        '1 sdm Madu',
                        'Topping: Granola, Kacang, Buah'
                    ],
                    'Cara': [
                        'Blend pisang, selai kacang, susu, dan protein powder hingga halus',
                        'Tambahkan oat, blend sebentar',
                        'Tuang ke mangkuk',
                        'Taburi dengan biji chia, granola, kacang, dan potongan buah',
                        'Teteskan madu di atasnya'
                    ],
                    'Nutrisi': {
                        'Kalori': '~650 kal',
                        'Protein': '30g',
                        'Karbohidrat': '75g',
                        'Lemak': '25g',
                        'Serat': '10g'
                    },
                    'Tips': [
                        'Tambahkan alpukat untuk lemak sehat ekstra',
                        'Bisa tambahkan kurma untuk manis alami'
                    ]
                },
                {
                    'Nama': 'Pancake Pisang dengan Selai Kacang',
                    'Bahan': [
                        '2 Pisang Matang (haluskan)',
                        '2 butir Telur',
                        '1/2 cangkir Tepung Terigu',
                        '1/4 cangkir Susu',
                        '2 sdm Selai Kacang',
                        '1 sdm Madu',
                        '1 sdt Baking Powder',
                        'Mentega untuk menggoreng'
                    ],
                    'Cara': [
                        'Campurkan pisang halus, telur, dan susu',
                        'Tambahkan tepung dan baking powder, aduk rata',
                        'Panaskan wajan dengan sedikit mentega',
                        'Tuang adonan, masak hingga bergelembung',
                        'Balik, masak sisi lain hingga kecokelatan',
                        'Sajikan dengan olesan selai kacang dan madu'
                    ],
                    'Nutrisi': {
                        'Kalori': '~520 kal',
                        'Protein': '18g',
                        'Karbohidrat': '68g',
                        'Lemak': '20g',
                        'Serat': '6g'
                    },
                    'Tips': ['Tambahkan chocolate chips untuk rasa lebih nikmat']
                },
                {
                    'Nama': 'French Toast dengan Nutella dan Pisang',
                    'Bahan': [
                        '3 lembar Roti Tawar Tebal',
                        '2 butir Telur',
                        '1/4 cangkir Susu Full Cream',
                        '2 sdm Nutella/Selai Cokelat',
                        '1 Pisang (iris)',
                        '1 sdm Mentega',
                        '1 sdm Madu',
                        'Sejumput Kayu Manis'
                    ],
                    'Cara': [
                        'Kocok telur dengan susu dan kayu manis',
                        'Celupkan roti ke dalam campuran telur',
                        'Panaskan mentega di wajan',
                        'Goreng roti hingga keemasan di kedua sisi',
                        'Oleskan nutella di atasnya',
                        'Tata irisan pisang',
                        'Teteskan madu dan sajikan'
                    ],
                    'Nutrisi': {
                        'Kalori': '~580 kal',
                        'Protein': '16g',
                        'Karbohidrat': '72g',
                        'Lemak': '26g',
                        'Serat': '5g'
                    },
                    'Tips': ['Gunakan roti brioche untuk rasa lebih kaya']
                },
                {
                    'Nama': 'Nasi Goreng Spesial dengan Telur Mata Sapi',
                    'Bahan': [
                        '1.5 cangkir Nasi Putih',
                        '2 butir Telur',
                        '50g Ayam Suwir',
                        '2 siung Bawang Putih',
                        '1 Bawang Bombay Kecil',
                        '2 sdm Kecap Manis',
                        '1 sdm Saus Tiram',
                        '2 sdm Minyak Goreng',
                        'Bawang Goreng untuk taburan'
                    ],
                    'Cara': [
                        'Panaskan minyak, goreng 1 telur mata sapi, sisihkan',
                        'Tumis bawang putih dan bombay hingga harum',
                        'Masukkan ayam suwir, tumis sebentar',
                        'Masukkan nasi, aduk rata',
                        'Tambahkan kecap manis dan saus tiram',
                        'Masak hingga bumbu meresap',
                        'Sajikan dengan telur mata sapi dan bawang goreng'
                    ],
                    'Nutrisi': {
                        'Kalori': '~620 kal',
                        'Protein': '25g',
                        'Karbohidrat': '78g',
                        'Lemak': '22g',
                        'Serat': '3g'
                    },
                    'Tips': ['Tambahkan kerupuk untuk kalori ekstra']
                }
            ])
        # MULAI PERBAIKAN LOGIKA DISINI: Menyatukan resep Makan Siang/Malam
        elif meal_time in ["Makan Siang", "Makan Malam"]:
            base_recipes = [
                {
                    'Nama': 'Nasi Merah dengan Salmon dan Alpukat',
                    'Bahan': [
                        '1.5 cangkir Nasi Merah Matang',
                        '150g Ikan Salmon (marinasi dengan garam, lada, lemon)',
                        '1 Alpukat Matang (iris)',
                        '2 sdm Minyak Zaitun',
                        '1/2 cangkir Brokoli Kukus',
                        'Perasan Lemon',
                        'Wijen Hitam untuk taburan'
                    ],
                    'Cara': [
                        'Panggang salmon yang sudah dimarinasi dalam oven 180°C (15-20 menit)',
                        'Masak nasi merah sesuai instruksi',
                        'Kukus brokoli hingga empuk tapi renyah (5-7 menit)',
                        'Tata nasi di piring',
                        'Letakkan salmon di sampingnya',
                        'Tambahkan irisan alpukat dan brokoli',
                        'Siram dengan minyak zaitun dan perasan lemon',
                        'Taburi wijen hitam'
                    ],
                    'Nutrisi': {
                        'Kalori': '~720 kal',
                        'Protein': '35g',
                        'Karbohidrat': '65g',
                        'Lemak': '35g',
                        'Serat': '12g'
                    },
                    'Tips': [
                        'Salmon kaya Omega-3 untuk kesehatan jantung',
                        'Alpukat memberikan lemak sehat'
                    ]
                },
                {
                    'Nama': 'Daging Sapi Tumis dengan Nasi dan Kentang',
                    'Bahan': [
                        '150g Daging Sapi (potong tipis)',
                        '1.5 cangkir Nasi Putih',
                        '1 Kentang Ukuran Sedang (potong wedges)',
                        '1/2 Paprika (iris)',
                        '1/2 Bawang Bombay (iris)',
                        '3 siung Bawang Putih (cincang)',
                        '2 sdm Kecap Manis',
                        '1 sdm Saus Tiram',
                        '2 sdm Minyak Goreng',
                        'Garam dan Lada'
                    ],
                    'Cara': [
                        'Goreng kentang wedges hingga keemasan, tiriskan',
                        'Panaskan minyak, tumis bawang putih dan bawang bombay',
                        'Masukkan daging sapi, masak hingga berubah warna',
                        'Tambahkan paprika, tumis sebentar',
                        'Bumbui dengan kecap manis, saus tiram, garam, lada',
                        'Masak hingga daging empuk dan bumbu meresap',
                        'Sajikan dengan nasi dan kentang goreng'
                    ],
                    'Nutrisi': {
                        'Kalori': '~780 kal',
                        'Protein': '40g',
                        'Karbohidrat': '85g',
                        'Lemak': '28g',
                        'Serat': '5g'
                    },
                    'Tips': ['Pilih daging sapi bagian has dalam untuk tekstur lembut']
                },
                {
                    'Nama': 'Ayam Goreng Tepung dengan Nasi dan Sayur',
                    'Bahan': [
                        '2 potong Paha Ayam',
                        '1.5 cangkir Nasi Putih',
                        '1/2 cangkir Tepung Terigu',
                        '1/4 cangkir Tepung Maizena',
                        '1 butir Telur',
                        'Bumbu: Bawang Putih, Ketumbar, Garam, Lada',
                        'Minyak untuk menggoreng',
                        'Tumis Kangkung sebagai pelengkap'
                    ],
                    'Cara': [
                        'Marinasi ayam dengan bumbu halus (30 menit)',
                        'Campurkan tepung terigu dan maizena',
                        'Celupkan ayam ke telur, lalu gulingkan di tepung',
                        'Goreng dengan minyak panas hingga kecokelatan dan matang',
                        'Tumis kangkung dengan bawang putih',
                        'Sajikan ayam goreng dengan nasi dan tumis kangkung'
                    ],
                    # RESEP LENGKAP DENGAN NUTRISI DAN TIPS
                    'Nutrisi': {
                        'Kalori': '~850 kal',
                        'Protein': '45g',
                        'Karbohidrat': '100g',
                        'Lemak': '30g',
                        'Serat': '5g'
                    },
                    'Tips': [
                        'Gunakan minyak yang baru untuk menggoreng',
                        'Ayam goreng adalah sumber kalori yang padat'
                    ]
                }
            ]
            recipes.extend(base_recipes)
            # END OF REPAIR FOR LUNCH/DINNER BLOCK

        elif meal_time == "Snack/Camilan":
            recipes.extend([
                {
                    'Nama': 'Smoothie Alpukat Cokelat',
                    'Bahan': [
                        '1 Alpukat Matang',
                        '1 cangkir Susu Full Cream',
                        '2 sdm Bubuk Cokelat Murni (Cocoa Powder)',
                        '1 sdm Madu',
                        'Es Batu'
                    ],
                    'Cara': [
                        'Masukkan semua bahan ke dalam blender',
                        'Blend hingga halus dan creamy',
                        'Sajikan segera'
                    ],
                    'Nutrisi': {
                        'Kalori': '~350 kal',
                        'Protein': '10g',
                        'Karbohidrat': '25g',
                        'Lemak': '25g',
                        'Serat': '8g'
                    },
                    'Tips': ['Bisa tambahkan biji chia untuk tekstur dan nutrisi ekstra']
                },
                {
                    'Nama': 'Roti Gandum dengan Keju dan Selai Kacang',
                    'Bahan': [
                        '2 lembar Roti Gandum',
                        '2 sdm Selai Kacang',
                        '1 slice Keju Cheddar',
                        '1/2 Pisang (iris)'
                    ],
                    'Cara': [
                        'Panggang roti sebentar',
                        'Olesi dengan selai kacang',
                        'Tambahkan keju dan irisan pisang',
                        'Sajikan'
                    ],
                    'Nutrisi': {
                        'Kalori': '~400 kal',
                        'Protein': '18g',
                        'Karbohidrat': '45g',
                        'Lemak': '18g',
                        'Serat': '7g'
                    },
                    'Tips': ['Keju memberikan lemak dan protein yang baik']
                }
            ])
    # END OF PENAMBAHAN BERAT BADAN

    # RETURN RESEP
    return recipes

if __name__ == "__main__":
    diet_suggestion()